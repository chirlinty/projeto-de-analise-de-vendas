import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

md("""# 📊 Análise de Vendas de E-commerce

Projeto de portfólio em Análise de Dados: limpeza, exploração (EDA) e geração de
insights de negócio a partir de uma base de pedidos de um e-commerce fictício.

**Etapas do projeto:**
1. Importação e inspeção dos dados
2. Limpeza e tratamento de dados
3. Análise exploratória (EDA)
4. Visualizações
5. Insights e recomendações de negócio
""")

code("""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
plt.rcParams["figure.figsize"] = (10, 5)

df = pd.read_csv("../data/vendas_ecommerce.csv", parse_dates=["data_pedido"])
df.head()
""")

md("## 1. Inspeção inicial dos dados")

code("""print("Dimensões:", df.shape)
df.info()
""")

code("""df.isna().sum().sort_values(ascending=False)
""")

md("""## 2. Limpeza dos dados

Problemas identificados:
- Linhas duplicadas
- Valores nulos em `preco_unitario`, `regiao` e `avaliacao_cliente`
- Inconsistência de texto em `categoria` (maiúsculas e espaços extras)
- Valores negativos em `quantidade` (erro de digitação)
""")

code("""df_limpo = df.copy()

# Remover duplicadas
qtd_antes = len(df_limpo)
df_limpo = df_limpo.drop_duplicates()
print(f"Duplicadas removidas: {qtd_antes - len(df_limpo)}")

# Padronizar texto da categoria
df_limpo["categoria"] = df_limpo["categoria"].str.strip().str.title()

# Corrigir quantidades negativas (erro de digitação -> valor absoluto)
df_limpo["quantidade"] = df_limpo["quantidade"].abs()

# Tratar nulos em preco_unitario: preencher pela mediana da categoria
df_limpo["preco_unitario"] = df_limpo.groupby("categoria")["preco_unitario"]\\
    .transform(lambda x: x.fillna(x.median()))

# Tratar nulos em regiao: preencher com "Não Informado"
df_limpo["regiao"] = df_limpo["regiao"].fillna("Não Informado")

# Criar coluna de receita
df_limpo["receita"] = (df_limpo["preco_unitario"] * df_limpo["quantidade"]) \\
    * (1 - df_limpo["desconto_pct"])

# Colunas de tempo úteis
df_limpo["mes"] = df_limpo["data_pedido"].dt.to_period("M").astype(str)
df_limpo["dia_semana"] = df_limpo["data_pedido"].dt.day_name()

print("Dimensões após limpeza:", df_limpo.shape)
df_limpo.isna().sum().sort_values(ascending=False)
""")

md("## 3. Análise Exploratória (EDA)")

code("""df_limpo[["preco_unitario", "quantidade", "desconto_pct", "receita"]].describe()
""")

md("### 3.1 Receita por categoria")

code("""receita_categoria = df_limpo.groupby("categoria")["receita"].sum().sort_values(ascending=False)
receita_categoria
""")

code("""fig, ax = plt.subplots()
sns.barplot(x=receita_categoria.values, y=receita_categoria.index, ax=ax, palette="viridis")
ax.set_title("Receita total por categoria de produto")
ax.set_xlabel("Receita (R$)")
ax.set_ylabel("Categoria")
plt.tight_layout()
plt.savefig("../images/receita_por_categoria.png", dpi=120)
plt.show()
""")

md("### 3.2 Evolução mensal da receita")

code("""receita_mensal = df_limpo.groupby("mes")["receita"].sum()

fig, ax = plt.subplots()
receita_mensal.plot(marker="o", ax=ax, color="#2E86AB")
ax.set_title("Evolução mensal da receita em 2024")
ax.set_xlabel("Mês")
ax.set_ylabel("Receita (R$)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("../images/receita_mensal.png", dpi=120)
plt.show()
""")

md("### 3.3 Receita por região")

code("""fig, ax = plt.subplots()
receita_regiao = df_limpo.groupby("regiao")["receita"].sum().sort_values(ascending=False)
sns.barplot(x=receita_regiao.index, y=receita_regiao.values, ax=ax, palette="mako")
ax.set_title("Receita total por região")
ax.set_xlabel("Região")
ax.set_ylabel("Receita (R$)")
plt.tight_layout()
plt.savefig("../images/receita_por_regiao.png", dpi=120)
plt.show()
""")

md("### 3.4 Distribuição de avaliações dos clientes")

code("""fig, ax = plt.subplots()
sns.countplot(x="avaliacao_cliente", data=df_limpo, ax=ax, palette="rocket")
ax.set_title("Distribuição das avaliações dos clientes")
ax.set_xlabel("Avaliação (1 a 5)")
ax.set_ylabel("Quantidade de pedidos")
plt.tight_layout()
plt.savefig("../images/distribuicao_avaliacoes.png", dpi=120)
plt.show()
""")

md("### 3.5 Ticket médio por segmento de cliente e canal de venda")

code("""pivot_ticket = df_limpo.pivot_table(
    index="segmento_cliente", columns="canal_venda", values="receita", aggfunc="mean"
)

fig, ax = plt.subplots()
sns.heatmap(pivot_ticket, annot=True, fmt=".0f", cmap="YlGnBu", ax=ax)
ax.set_title("Ticket médio (R$) por segmento de cliente x canal de venda")
plt.tight_layout()
plt.savefig("../images/ticket_medio_heatmap.png", dpi=120)
plt.show()
""")

md("### 3.6 Receita por dia da semana")

code("""ordem_dias = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
receita_dia = df_limpo.groupby("dia_semana")["receita"].sum().reindex(ordem_dias)

fig, ax = plt.subplots()
sns.barplot(x=receita_dia.index, y=receita_dia.values, ax=ax, palette="crest")
ax.set_title("Receita total por dia da semana")
ax.set_xlabel("Dia da semana")
ax.set_ylabel("Receita (R$)")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig("../images/receita_por_dia_semana.png", dpi=120)
plt.show()
""")

md("""## 4. Principais Insights

Os números abaixo são recalculados automaticamente a partir dos dados limpos.
""")

code("""categoria_top = receita_categoria.idxmax()
regiao_top = receita_regiao.idxmax()
mes_top = receita_mensal.idxmax()
ticket_medio_geral = df_limpo["receita"].mean()
nota_media = df_limpo["avaliacao_cliente"].mean()

print(f"Categoria com maior receita: {categoria_top}")
print(f"Região com maior receita: {regiao_top}")
print(f"Mês de maior receita: {mes_top}")
print(f"Ticket médio geral: R$ {ticket_medio_geral:,.2f}")
print(f"Nota média de avaliação: {nota_media:.2f} / 5")
""")

md("""### Conclusões de negócio

- A categoria e a região líderes em receita indicam onde concentrar investimento
  em marketing e estoque.
- A sazonalidade mensal ajuda a planejar campanhas e reposição de estoque.
- O heatmap de ticket médio por segmento x canal mostra em quais combinações
  vale a pena investir em programas de fidelidade ou upsell.
- A distribuição de avaliações aponta o nível geral de satisfação e possíveis
  pontos de atenção na experiência do cliente.

> Este notebook foi construído como projeto de portfólio para demonstrar
> habilidades de limpeza de dados, análise exploratória e storytelling com dados
> usando Python (pandas, matplotlib, seaborn).
""")

nb["cells"] = cells
with open("/home/claude/projeto-analise-vendas/notebooks/analise_vendas.ipynb", "w") as f:
    nbf.write(nb, f)

print("Notebook criado com sucesso.")
