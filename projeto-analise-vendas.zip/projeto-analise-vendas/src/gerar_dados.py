"""
Gera um dataset sintético de vendas de e-commerce para fins de estudo/portfólio.
Inclui sujeiras propositais (nulos, duplicados, inconsistências) para simular
um cenário real de limpeza de dados.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 6000

categorias = ["Eletrônicos", "Moda", "Casa e Decoração", "Beleza", "Esporte", "Livros"]
regioes = ["Norte", "Nordeste", "Centro-Oeste", "Sudeste", "Sul"]
segmentos = ["Novo Cliente", "Recorrente", "VIP"]
canais = ["App", "Site", "Marketplace"]

precos_base = {
    "Eletrônicos": 850,
    "Moda": 120,
    "Casa e Decoração": 200,
    "Beleza": 80,
    "Esporte": 180,
    "Livros": 55,
}

datas = pd.date_range("2024-01-01", "2024-12-31", freq="D")

linhas = []
for i in range(N):
    data = np.random.choice(datas)
    categoria = np.random.choice(categorias, p=[0.22, 0.25, 0.15, 0.18, 0.12, 0.08])
    preco_unit = max(10, np.random.normal(precos_base[categoria], precos_base[categoria] * 0.25))
    quantidade = np.random.choice([1, 1, 1, 2, 2, 3, 4, 5], p=[0.35,0.2,0.1,0.15,0.08,0.06,0.04,0.02])
    desconto = np.random.choice([0, 0, 0, 0.05, 0.10, 0.15, 0.20], p=[0.5,0.1,0.1,0.1,0.1,0.05,0.05])
    regiao = np.random.choice(regioes, p=[0.07, 0.20, 0.10, 0.45, 0.18])
    segmento = np.random.choice(segmentos, p=[0.45, 0.40, 0.15])
    canal = np.random.choice(canais, p=[0.4, 0.35, 0.25])
    avaliacao = np.random.choice([1,2,3,4,5, np.nan], p=[0.03,0.05,0.12,0.35,0.35,0.10])

    linhas.append({
        "id_pedido": f"PED{100000+i}",
        "data_pedido": data,
        "categoria": categoria,
        "preco_unitario": round(preco_unit, 2),
        "quantidade": quantidade,
        "desconto_pct": desconto,
        "regiao": regiao,
        "segmento_cliente": segmento,
        "canal_venda": canal,
        "avaliacao_cliente": avaliacao,
    })

df = pd.DataFrame(linhas)

# Sujeiras propositais para o exercício de limpeza
# 1) Duplicar algumas linhas
duplicadas = df.sample(120, random_state=1)
df = pd.concat([df, duplicadas], ignore_index=True)

# 2) Nulos em preco_unitario e regiao
idx_nulos_preco = df.sample(80, random_state=2).index
df.loc[idx_nulos_preco, "preco_unitario"] = np.nan

idx_nulos_regiao = df.sample(60, random_state=3).index
df.loc[idx_nulos_regiao, "regiao"] = np.nan

# 3) Inconsistência de texto (maiúsculas/minúsculas/espaços)
idx_sujo = df.sample(150, random_state=4).index
df.loc[idx_sujo, "categoria"] = df.loc[idx_sujo, "categoria"].str.upper() + "  "

# 4) Quantidade negativa por erro de digitação
idx_neg = df.sample(15, random_state=5).index
df.loc[idx_neg, "quantidade"] = -df.loc[idx_neg, "quantidade"]

# 5) Embaralhar linhas
df = df.sample(frac=1, random_state=6).reset_index(drop=True)

df.to_csv("/home/claude/projeto-analise-vendas/data/vendas_ecommerce.csv", index=False)
print("Dataset gerado com sucesso:", df.shape)
